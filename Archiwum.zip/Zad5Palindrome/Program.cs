﻿using System;

namespace Zad5Palindrome
{
    class Palindrome
    {
        string word;
        public Palindrome(string w1)
        {
            word = w1;
        }

        public void Check()
        {
            //usuwam inne znaki
            for (int i = 0; i < word.Length; i++)
            {
                if (word[i] < 65 || (word[i] > 90 && word[i] < 97) || word[i] > 122)
                {
                    word = word.Remove(i, 1);
                    i--;
                }
            }

            //sprawdzam czy palindrom
            bool isPalindrome = true;
            for (int i = 0; i < (word.Length / 2); i++)
            {
                if (word[i] != word[word.Length - 1 - i])
                    isPalindrome = false;
            }

            //wyjątki
            if (word.Length == 0)
                isPalindrome = false;

            //wypisuje odp
            Console.Write("Palindrome? ");
            if (isPalindrome)
                Console.WriteLine("YES");
            else
                Console.WriteLine("NO");


        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("You give the word and I will check if it is a palindome.\n- if there will be other characters exclude the letters, I will skip them\n- I look at uppercase and lowercase letter so for example, the word 'Kok' is not a palindome but word 'kok' is\n");
            Console.Write("Your word:");

            string word = Console.ReadLine();
            Palindrome p1 = new Palindrome(word);

            p1.Check();

            Console.ReadKey();
        }
    }
}

﻿using System;

namespace Zad11CommonDigit
{

    class CommonDigit
    {

        //opis
        public void Description()
        {
            Console.WriteLine("Instruction:");
            Console.WriteLine("-Write number how long will be your array");
            Console.WriteLine("-Press Enter");
            Console.WriteLine("-Array: Write numbers separate them with spaces (there cannot be spaces before or after the numbers)");
            Console.WriteLine("-Press Enter");

            Console.WriteLine("Your program will output the most occurring digit that appears in the numbers of this array./n/n");
        }

        public bool Compare(string numbers, int N)
        {


            int n = 1;
            for (int i = 0; i < numbers.Length; i++)
            {
                while (numbers[i] == ' ')
                {
                    n++;
                    i++;
                }
            }
            if (n == N)
                return true;
            else
                return false;

        }

        public void MostCommon(string numbers)
        {
            int i = 0;
            int[] T = new int[10];//dziesiec bo mamy 10 cyfr(system dziesietny)

            for (int j = 0; j < 10; j++)
                T[j] = 0;

            while (i != numbers.Length)
            {
                if (numbers[i] == '0')
                    T[0]++;
                else if (numbers[i] == '1')
                    T[1]++;
                else if (numbers[i] == '2')
                    T[2]++;
                else if (numbers[i] == '3')
                    T[3]++;
                else if (numbers[i] == '4')
                    T[4]++;
                else if (numbers[i] == '5')
                    T[5]++;
                else if (numbers[i] == '6')
                    T[6]++;
                else if (numbers[i] == '7')
                    T[7]++;
                else if (numbers[i] == '8')
                    T[8]++;
                else if (numbers[i] == '9')
                    T[9]++;
                i++;
            }

            int max = 0;
            bool localMax;
            for (int j = 0; j < 10; j++)
            {
                localMax = true;
                for (int k = 0; k < 10; k++)
                {
                    if (T[j] < T[k])
                        localMax = false;

                }
                if (localMax)
                    max = j;
            }
            Console.WriteLine(max);

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            CommonDigit c1 = new CommonDigit();
            c1.Description();
            int N = Convert.ToInt32(Console.ReadLine());
            string numbers;

            if (N >= 2 && N <= 20)
            {
                numbers = Console.ReadLine();
                if (c1.Compare(numbers, N))
                    c1.MostCommon(numbers);
                else
                    Console.WriteLine("error: The number of elements in the array is different than N");
            }

            else
                Console.WriteLine("error: N don't exist in interval [2,20]");

            Console.ReadKey();
        }
    }
}

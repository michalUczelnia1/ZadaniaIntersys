﻿using System;

namespace Zad8FindingPrimes
{

    class FindingPrimes
    {
        //opis
        public void Description()
        {
            Console.WriteLine("Instruction:");
            Console.WriteLine("-Write how much test cases You want to do");
            Console.WriteLine("-Press Enter");
            Console.WriteLine("-Now in one line write interval: write one number, space, next number(first smaller number)");
            Console.WriteLine("the numbers should match (1 <= m <= n <= 10^9, n – m <= 10^5)");
            Console.WriteLine("-Press Enter");
            Console.WriteLine("-Repeat as much as You write in first line(test cases)\n");
            Console.WriteLine("Program will count how much Primes are betwen these two numbers(include them)\n\n");
        }

        //liczby ze stringa przepisuje do tablicy
        public int[] TakeIntNumber(string numbers)
        {

            int[] myNumbers = new int[2];
            int k = 0;
            string number = "";

            for (int i = 0; i < numbers.Length; i++)
            {
                while (numbers[i] != ' ')
                {
                    number += numbers[i];
                    i++;
                    if (i == numbers.Length)
                        break;
                }

                myNumbers[k] = Convert.ToInt32(number);
                k++;
                number = "";
            }
            return myNumbers;
        }

        //sprawdza czy konkretna liczba jest pierwsza
        public bool IsPrime(int x)
        {
            bool indivisible = true;

            for (int i = x - 1; i > 1; i--)
            {
                if (x % i == 0)
                {
                    indivisible = false;
                    break;
                }
            }
            //wyjatki
            if (x == 1 || x <= 0)
                return false;

            return indivisible;
        }

        //liczy ile pierwszych
        public int HowMuchPrime(int a, int b)
        {
            int ile = 0;
            for (int i = a; i <= b; i++)
            {
                if (IsPrime(i))
                {
                    ile++;
                }
            }


            return ile;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            FindingPrimes p1 = new FindingPrimes();

            p1.Description();

            int howMuch, m, n;
            string result = "";
            string numbers;
            int[] numberArray;
            howMuch = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < howMuch; i++)
            {
                numbers = Console.ReadLine();

                numberArray = p1.TakeIntNumber(numbers);

                m = numberArray[0];
                n = numberArray[1];

                //(1 <= m <= n <= 10^9, n – m <= 10^5)
                if (m >= 1 && n >= 1 && m <= 1000000000 && n <= 1000000000 && n - m <= 100000)
                    result += (p1.HowMuchPrime(m, n) + "\n");
                else
                {
                    result += "error: the numbers don't match (1 <= m <= n <= 10^9, n – m <= 10^5)\n";
                    break;
                }
            }


            Console.WriteLine("\n" + result);





            Console.ReadKey();
        }
    }
}

﻿using System;

namespace Zad6Permutation
{
    class Permutation
    {
        public void Description()
        {
            Console.WriteLine("Instruction:\n-Giving numbers separate them with spaces (there cannot be spaces before or after the numbers)\n-In the array should be exactly 11 numbers\n");
            Console.WriteLine("Program should say you if there's a permutation or not");
        }

        //konwertuje ze string to int[]
        public int[] ConvertMe(string strArray)
        {
            int[] intArray = new int[11];
            int j;//licznik 
            string strNumber = "";

            //----------------pierwsza liczbe wypisuje
            j = 0;
            while (strArray[j] >= 48 && strArray[j] <= 57)//jesli jest cyferka
            {
                strNumber += strArray[j];
                j++;
            }
            intArray[0] = Convert.ToInt32(strNumber);
            strNumber = "";
            //------

            //wpisuje listy do tablicy
            int k = 1;
            for (int i = 0; i < strArray.Length; i++)
            {

                if (strArray[i] == 32)//spacja
                {
                    i++;
                    j = i;

                    //jesli cyferka to docaje do mojej liczby
                    while (strArray[j] >= 48 && strArray[j] <= 57)
                    {
                        strNumber += strArray[j];
                        j++;

                        if (j == strArray.Length)
                            break;
                    }

                    intArray[k] = Convert.ToInt32(strNumber);
                    k++;
                    strNumber = "";
                }
            }


            return intArray;
        }

        //czy tablice maja takie same cyferki
        public bool IfTheSame(int[] T1, int[] T2)
        {
            bool same = true;
            //int i=0;
            Array.Sort(T1);
            Array.Sort(T2);

            for (int i = 0; i < T1.Length; i++)
            {
                if (T1[i] != T2[i])
                    same = false;
            }

            return same;
        }

        //wypisz
        public void Write(int[] T)
        {
            Console.WriteLine("Write array:");
            for (int i = 0; i < 11; i++)
                Console.WriteLine(i + 1 + " " + T[i]);

        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Permutation p1 = new Permutation();
            p1.Description();

            Console.WriteLine("Write first array");
            string strTab1 = Console.ReadLine();

            Console.WriteLine("Write second array");
            string strTab2 = Console.ReadLine();

            int[] Tab1 = p1.ConvertMe(strTab1);
            int[] Tab2 = p1.ConvertMe(strTab2);

            Console.WriteLine("Is there a permutation?");

            bool Czy;
            Czy = p1.IfTheSame(Tab1, Tab2);
            if (Czy == true)
                Console.WriteLine("YES");
            else
                Console.WriteLine("NO");
            //1 2 3 4 5 6 7 8 9 10 11
            //10 11 1 2 3 4 5 6 7 8 9


            Console.ReadKey();
        }
    }
}

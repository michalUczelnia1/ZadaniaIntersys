﻿using System;

namespace Zad4ReverseArray
{
    class ReverseArray
    {
        //opis
        public void Description()
        {
            Console.WriteLine("Instruction\n-First write how long will be Array and press Enter");
            Console.WriteLine("-Array: Write numbers separate them with spaces (there cannot be spaces before or after the numbers)");
            Console.WriteLine("-Press Enter");
            Console.WriteLine("Program will reverse array\n");
        }


        //ile cyfer w tablicy
        public int HowMuch(string numbers)
        {
            int n = 1;
            for (int i = 0; i < numbers.Length; i++)
            {
                while (numbers[i] == ' ')
                {
                    n++;
                    i++;
                }
            }
            return n;
        }

        //zamieniam string na tablice int[]
        public int[] ConvertMe(string strArray)
        {

            int[] intArray = new int[HowMuch(strArray)];
            int j;//licznik 
            string strNumber = "";

            //----------------pierwsza liczbe wypisuje
            j = 0;
            while (strArray[j] >= 48 && strArray[j] <= 57)//jesli jest cyferka
            {
                strNumber += strArray[j];
                j++;
            }
            intArray[0] = Convert.ToInt32(strNumber);
            strNumber = "";
            //------

            //wpisuje listy do tablicy
            int k = 1;
            for (int i = 0; i < strArray.Length; i++)
            {

                if (strArray[i] == 32)//spacja
                {
                    i++;
                    j = i;

                    //jesli cyferka to docaje do mojej liczby
                    while (strArray[j] >= 48 && strArray[j] <= 57)
                    {
                        strNumber += strArray[j];
                        j++;

                        if (j == strArray.Length)
                            break;
                    }

                    intArray[k] = Convert.ToInt32(strNumber);
                    k++;
                    strNumber = "";
                }
            }


            return intArray;
        }

        //odwracam tab
        public int[] ReverseOrder(int[] arrayNumbers)
        {
            int[] newArray = new int[arrayNumbers.Length];
            for (int i = 0; i < arrayNumbers.Length; i++)
                newArray[i] = arrayNumbers[arrayNumbers.Length - 1 - i];

            return newArray;
        }


    }
    class Program
    {
        static void Main(string[] args)
        {
            ReverseArray r1 = new ReverseArray();
            r1.Description();

            int N = Convert.ToInt32(Console.ReadLine());
            string strNumbers = Console.ReadLine();
            int[] arrayNumbers = r1.ConvertMe(strNumbers);

            arrayNumbers = r1.ReverseOrder(arrayNumbers);


            if (N == arrayNumbers.Length)
            {
                foreach (var item in arrayNumbers)
                    Console.Write(item + " ");
            }

            else
                Console.WriteLine("error: The number of elements in the array is different than N");

            Console.ReadKey();
        }
    }
}

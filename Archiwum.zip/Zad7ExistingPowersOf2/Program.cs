﻿using System;
using System.Collections.Generic;

namespace Zad7ExistingPowersOf2
{
    class ExistingPowersOf2
    {
        public int[] Input()
        {
            Console.WriteLine("How much numbers You will write?");
            int N = Convert.ToInt32(Console.ReadLine());
            int[] myArray = new int[N];

            Console.WriteLine("Write:");
            for (int i = 0; i < N; i++)
            {
                myArray[i] = Convert.ToInt32(Console.ReadLine());
            }
            return myArray;
        }

        public List<uint> Decomposition(int a, List<uint> myList)
        {
             for (int i = 32; i >=0 ; i--)
            {
                uint powOf2 = (uint)(Math.Pow(2, i));
                int oryginalA = a;
                if (a >= powOf2 && powOf2 != 0) 
                {
                    while(a % powOf2 != 0)
                        a--;

                    if (a % powOf2 == 0)
                    {
                        myList.Add(powOf2);
                        a = oryginalA - a;
                    }
                }
            }
            return myList;
        }

        public List<uint> FinalArray(int[] T)
        {
            List<uint> myList = new List<uint>();
            for (int i = 0; i < T.Length; i++)
            {
                myList = Decomposition(T[i], myList);
            }

            myList.Sort();
            for (int i = 0; i < myList.Count-1; i++)
            {
                if (myList[i] == myList[i + 1])
                {
                    myList.RemoveAt(i + 1);
                    i--;
                }

            }

            return myList;
        }

        public void Output()
        {
            List<uint> myList = new List<uint>();
            int[] Tab = Input();

            myList = FinalArray(Tab);
            if (myList.Count == 0)
            {
                Console.WriteLine("NA");
            }
            else
            {

                for (int i = 0; i < myList.Count; i++)
                {
                    Console.Write(myList[i]);
                    if (i <= myList.Count - 2)
                    {
                        Console.Write(",");
                    }
                }

            }
        }
    }




    class Program
    {
        static void Main(string[] args)
        {
            ExistingPowersOf2 p1 = new ExistingPowersOf2();
            p1.Output();
        }
    }
}

﻿using System;

namespace Zad12DigitSum
{
    class DigitSum
    {

        //opis
        public void Description()
        {
            Console.WriteLine("Instruction:");
            Console.WriteLine("-Write number how long will be your array");
            Console.WriteLine("-Press Enter");
            Console.WriteLine("-Array: Write numbers separate them with spaces (there cannot be spaces before or after the numbers)");
            Console.WriteLine("-Press Enter");

            Console.WriteLine("Your program will output the position (0-based) of the array in which the value in that position has the maximum digit sum possible.\n\n");
        }


        //ile cyfer w tablicy
        public int HowMuch(string numbers)
        {
            int n = 1;
            for (int i = 0; i < numbers.Length; i++)
            {
                while (numbers[i] == ' ')
                {
                    n++;
                    i++;
                }
            }
            //Console.WriteLine(n);
            return n;
        }

        //zamieniam string na tablice int[]
        public int[] ConvertMe(string strArray)
        {

            int[] intArray = new int[HowMuch(strArray)];
            int j;//licznik 
            string strNumber = "";

            //----------------pierwsza liczbe wypisuje
            j = 0;
            while (strArray[j] >= 48 && strArray[j] <= 57)//jesli jest cyferka
            {
                strNumber += strArray[j];
                j++;
            }
            intArray[0] = Convert.ToInt32(strNumber);
            strNumber = "";
            //------

            //wpisuje listy do tablicy
            int k = 1;
            for (int i = 0; i < strArray.Length; i++)
            {

                if (strArray[i] == 32)//spacja
                {
                    i++;
                    j = i;

                    //jesli cyferka to docaje do mojej liczby
                    while (strArray[j] >= 48 && strArray[j] <= 57)
                    {
                        strNumber += strArray[j];
                        j++;

                        if (j == strArray.Length)
                            break;
                    }

                    intArray[k] = Convert.ToInt32(strNumber);
                    k++;
                    strNumber = "";
                }
            }


            return intArray;
        }

        //zamieniam liczby na sume ich cyfer np 21-->3
        public int[] Change(int[] numbers)
        {
            string strNumber;

            int sumNumber = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                strNumber = Convert.ToString(numbers[i]);


                for (int j = 0; j < strNumber.Length; j++)
                {
                    sumNumber += Convert.ToInt32(Convert.ToString(strNumber[j]));
                }
                numbers[i] = sumNumber;
                sumNumber = 0;
            }

            return numbers;
        }

        //z nowej tablicy wybieram element z nawiekszym numerem
        public int Biggest(int[] numbers)
        {
            int max = 0;
            bool biggest = true;
            for (int i = 0; i < numbers.Length; i++)
            {

                biggest = true;
                for (int j = 0; j < numbers.Length; j++)
                {
                    if (numbers[i] < numbers[j])
                        biggest = false;

                }
                if (biggest)
                    max = i;

            }


            return max;
        }



    }
    class Program
    {
        static void Main(string[] args)
        {
            DigitSum s1 = new DigitSum();
            s1.Description();
            int N = Convert.ToInt32(Console.ReadLine());
            string strNumbers = Console.ReadLine();
            int[] arrayNumbers;


            arrayNumbers = s1.ConvertMe(strNumbers);
            arrayNumbers = s1.Change(arrayNumbers);

            //the greatest one is the last one
            if (N == arrayNumbers.Length)
                Console.WriteLine(s1.Biggest(arrayNumbers));

            else
                Console.WriteLine("error: The number of elements in the array is different than N");


            Console.ReadKey();
        }
    }
}
